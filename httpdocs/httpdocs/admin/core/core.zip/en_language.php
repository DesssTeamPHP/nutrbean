<?php
/*******************************Defines alert Names as Constant******************************/

	define('MYPROFILE_SUCCESS', 'User Profile Successfully Updated'); //Name Declaration For Myprofile success     
    define('CATEGORIES_SUCCESSADD', 'Successfully Added'); //Name Declaration For CATEGORIES TABLES
    define('CATEGORIES_SUCCESSUPD', 'Successfully Updated'); //Name Declaration For CATEGORIES TABLES
	define('CATEGORIES_SUCCESSDEL', 'Successfully Deleted'); //Name Declaration For CATEGORIES TABLES 
	define('SUBCATEGORIES_SUCCESS', 'Successfully Deleted'); //Name Declaration For CATEGORIES TABLES 
	define('CATEGORIES_HAVECHILD', 'This Category Have Sub Category'); //Name Declaration For CATEGORIES TABLES
	
	
	define('URLREWRITE_ADD', 'ReWrite Rule Created'); //Name Declaration For URL REWRITE  Add success
	define('URLREWRITE_DEL', 'ReWrite Rule Deleted '); //Name Declaration For URL REWRITE  Delete success
	define('URLREWRITE_UPDATE', 'ReWrite Updated  '); //Name Declaration For URL REWRITE  Delete success
	define('TAX_ADD', 'Tax Successfully Added'); //Name Declaration For URL REWRITE  Delete success
	define('TAX_UPDATE', 'Tax Successfully Updated'); //Name Declaration For URL REWRITE  Delete success
	define('TAX_DEL', 'Tax Successfully Deleted'); //Name Declaration For URL REWRITE  Delete success
	define('PRODUCT_ADD', 'Product Successfully Added'); //Name Declaration For URL REWRITE  Delete success
	define('PRODUCT_UPDATE', 'Product Successfully Updated'); //Name Declaration For URL REWRITE  Delete success
	define('PRODUCT_DEL', 'Product Successfully Deleted'); //Name Declaration For URL REWRITE  Delete success
	define('ORDERDETAILS_ADD', 'Order Details Successfully Added'); //Name Declaration For URL REWRITE  Delete success
	define('ORDERDETAILS_UPDATE', 'Order Details Successfully Updated'); //Name Declaration For URL REWRITE  Delete success
	define('ORDERDETAILS_DEL', 'Order Details Successfully Deleted'); //Name Declaration For URL REWRITE  Delete success
	define('INVOICE_DEL', 'Invoice Successfully Deleted'); //Name Declaration For URL REWRITE  Delete success
	define('USERDETAILS_DEL', 'User Details Successfully Deleted'); //Name Declaration For URL REWRITE  Delete success
	define('MAINPAGE_ADD', 'Menu Successfully Added'); //Name Declaration For URL REWRITE  Delete success
	define('MAINPAGE_UPDATE', 'Menu Successfully Updated'); //Name Declaration For URL REWRITE  Delete success
	define('MAINPAGE_DEL', 'Menu Successfully Deleted'); //Name Declaration For URL REWRITE  Delete success
	define('SOCIAL_ADD', 'Social Successfully Added'); //Name Declaration For URL REWRITE  Delete success
	define('SOCIAL_UPDATE', 'Social Successfully Updated'); //Name Declaration For URL REWRITE  Delete success
	define('SOCIAL_DEL', 'Social Successfully Deleted'); //Name Declaration For URL REWRITE  Delete success
	define('REQUEST_DEL', 'Request Quote Successfully Deleted'); //Name Declaration For URL REWRITE  Delete success
	define('MENUGROUP_ADD', 'Menu Group Successfully Added'); //Name Declaration For URL REWRITE  Delete success
	define('MENUGROUP_UPDATE', 'Menu Group Successfully Updated'); //Name Declaration For URL REWRITE  Delete success
	define('MENUGROUP_DEL', 'Menu Group Successfully Deleted'); //Name Declaration For URL REWRITE  Delete success
	define('USERLIST_ADD', 'User  Successfully Added'); //Name Declaration For URL REWRITE  Delete success
	define('USERLIST_UPDATE', 'User Successfully Updated'); //Name Declaration For URL REWRITE  Delete success
	define('USERLIST_DEL', 'User Successfully Deleted'); //Name Declaration For URL REWRITE  Delete success
	define('MENUNAME_ADD', 'Menu Name  Successfully Added'); //Name Declaration For URL REWRITE  Delete success
	define('MENUNAME_UPDATE', 'Menu Name Successfully Updated'); //Name Declaration For URL REWRITE  Delete success
	define('MENUNAME_DEL', 'Menu Name Successfully Deleted'); //Name Declaration For URL REWRITE  Delete success
	define('CONTENT_ADD', 'Content  Successfully Added'); //Name Declaration For URL REWRITE  Delete success
	define('CONTENT_UPDATE', 'Content Successfully Updated'); //Name Declaration For URL REWRITE  Delete success
	define('ANALITIC_ADD', 'Analitic  Successfully Added'); //Name Declaration For URL REWRITE  Delete success
	define('BRANDS_ADD', 'Brand  Successfully Added'); //Name Declaration For URL REWRITE  Delete success
	define('BRANDS_UPDATE', 'Brand Successfully Updated'); //Name Declaration For URL REWRITE  Delete success
	define('BRANDS_DEL', 'Brand Successfully Deleted'); //Name Declaration For URL REWRITE  Delete success
	define('ADMINGROUP_ADD', 'Admin Group  Successfully Added'); //Name Declaration For URL REWRITE  Delete success
	define('ADMINGROUP_UPDATE', 'Admin Group Successfully Updated'); //Name Declaration For URL REWRITE  Delete success
	define('ADMINGROUP_DEL', 'Admin Group Successfully Deleted'); //Name Declaration For URL REWRITE  Delete success
	define('BLOG_ADD', 'Blog  Successfully Added'); //Name Declaration For URL REWRITE  Delete success
	define('BLOG_UPDATE', 'Blog Successfully Updated'); //Name Declaration For URL REWRITE  Delete success
	define('BLOG_DEL', 'Blog Successfully Deleted'); //Name Declaration For URL REWRITE  Delete success
	define('PUBLISH_ADD', 'Blog Publish Successfully'); //Name Declaration For URL REWRITE  Delete success
	define('HOMEBANNER_ADD', 'Home Banner  Successfully Added'); //Name Declaration For URL REWRITE  Delete success
	define('HOMEBANNER_UPDATE', 'Home Banner Successfully Updated'); //Name Declaration For URL REWRITE  Delete success
	define('HOMEBANNER_DEL', 'Home Banner Successfully Deleted'); //Name Declaration For URL REWRITE  Delete success
	define('TESTIMONIAL_ADD', 'Testimonial  Successfully Added'); //Name Declaration For URL REWRITE  Delete success
	define('TESTIMONIAL_UPDATE', 'Testimonial Successfully Updated'); //Name Declaration For URL REWRITE  Delete success
	define('TESTIMONIAL_DEL', 'Testimonial Successfully Deleted'); //Name Declaration For URL REWRITE  Delete success
	define('FREQUENT_ADD', 'Frequent  Successfully Added'); //Name Declaration For URL REWRITE  Delete success
	define('FREQUENT_UPDATE', 'Frequent Successfully Updated'); //Name Declaration For URL REWRITE  Delete success
	define('FREQUENT_DEL', 'Frequent Successfully Deleted'); //Name Declaration For URL REWRITE  Delete success
	
	define('VIEWDETAIL_ADD', 'Footer Detail  Successfully Added'); //Name Declaration For URL REWRITE  Delete success
	define('VIEWDETAIL_UPDATE', 'Footer Detail Successfully Updated'); //Name Declaration For URL REWRITE  Delete success
	define('VIEWDETAIL_DEL', 'Footer Detail Successfully Deleted'); //Name Declaration For URL REWRITE  Delete success
?>

