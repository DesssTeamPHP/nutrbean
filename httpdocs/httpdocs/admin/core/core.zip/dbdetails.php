<?
 //Database Details
 /*******************************************************************************
  * Developed By Desss Inc
  * Copyright (c) 2014 Desss Inc. All rights reserved
  *
 ******************************************************************************/
		
	define('DBMS', 'MYSQL');  
	define('DB_HOST','localhost');  
	define('DB_USER','root'); 
	define('DB_PASS',''); 
	define('DB_NAME','desss_ecommerce'); 
?>
