<?php
/*******************************Defines Table Names as Constant******************************/

	define('ADMIN', 'admin'); //Name Declaration For ADMIN TABLES
    define('SOCIALMEDIA', ' social_media_tbl'); //Name Declaration For SOCIALMEDIA TABLES
    define('REQUESTQUOTE', 'request_quote'); //Name Declaration For REQUESTQUOTE TABLES
    define('TESTIMONIAL', 'testimonial_tbl'); //Name Declaration For  TESTIMONIAL TABLES
	define('CONTACT', 'contact_tbl'); //Name Declaration For  CONTACT TABLES
	define('HOMEBANNER', 'home_banner'); //Name Declaration For  HOMEBANNER TABLES
	define('IMAGEGALLERY', 'image_gallery'); //Name Declaration For  IMAGEGALLERY TABLES
	define('BLOG', 'blog_tbl'); //Name Declaration For  BLOG TABLES
	define('ANALITIC', 'analitic_tbl'); //Name Declaration For  ANALITIC TABLES
	define('CMSMENUTABLE', 'cms_menu_tbl'); //Name Declaration For  CMSMENUTABLE TABLES 
	define('USERCMSLINKTABLE', 'user_cmsmenu_link_tbl'); //Name Declaration For  USERCMSLINKTABLE TABLES
    define('MENUPAGETABLE', 'menu_page_tbl'); //Name Declaration For  MENUPAGETABLE TABLES
    define('MAP', 'tbl_map'); //Name Declaration For  MAP TABLES
    define('INDUSTRY', 'industry'); //Name Declaration For  INDUSTRY TABLES
    define('TECNOLOGY', 'technology_tbl'); //Name Declaration For  TECNOLOGY TABLES
	define('CLIENT', 'clients_tbl'); //Name Declaration For  CLIENT TABLES
	define('SITECATTABLE', 'sitecat_tbl'); //Name Declaration For  SITECAT TABLES
	define('SITEDETAILS', 'site_tbl'); //Name Declaration For  SITEDETAILS TABLES
	define('FOOTERMENU', 'footer_menu'); //Name Declaration For  FOOTERMENU TABLES
	define('HOMECLIENTS', 'homeclients'); //Name Declaration For  HOMECLIENTS TABLES
	define('PAGECATEGORY', 'page_category'); //Name Declaration For  HOMECLIENTS TABLES
	define('CONTENTINFO', 'contentinfo'); //Name Declaration For  HOMECLIENTS TABLES
	define('FEATURED', 'featured_table'); //Name Declaration For  FEATURED TABLES
	define('TRACKING', 'tracking_tbl'); //Name Declaration For  TRACKING TABLES
	define('USERTABLE', 'user_tbl'); //Name Declaration For  USERTABLE TABLES
	define('CITYIP', 'cityip'); //Name Declaration For  USERTABLE TABLES
	define('GROUP', 'group_table'); //Name Declaration For  GROUP TABLES 
	define('ADMINCMSMENU', 'admin_cms_menu'); //Name Declaration For  ADMINCMSMENU TABLES  
	define('MENUGROUP', 'menu_group'); //Name Declaration For  MENUGROUP TABLES 
	define('MENUGROUPCHILD', 'menu_group_child'); //Name Declaration For  MENUGROUPCHILD TABLES 
	define('CONTENTTAB', 'content_tab'); //Name Declaration For  MENUGROUPCHILD TABLES 
	define('CONTENTTABIMAGE', 'content_tab_image'); //Name Declaration For  MENUGROUPCHILD TABLES
	define('SUBPAGEBANNERNEW', 'sub_page_banner_new'); //Name Declaration For  MENUGROUPCHILD TABLES
	define('CATEGORIES', 'categories'); //Name Declaration For  CATEGORIES TABLES
	define('PRODUCTS', 'products'); //Name Declaration For  CATEGORIES TABLES
	define('BRANDS', 'brands'); //Name Declaration For  CATEGORIES TABLES
	define('URLREWRITE_TBL', 'urlrewrite_tbl'); //Url Rewrite table urlrewrite_edit, urlrewrite , rewrite_ajax
	define('ORDERDETAILS', 'order_details'); //Name Declaration For  CATEGORIES TABLES 
	define('TAX', 'tax'); //Name Declaration For  CATEGORIES TABLES
	define('INVOICE_TBL', 'invoice_tbl'); //Name Declaration For  CATEGORIES TABLES
	define('SIGNUP_TBL', 'user_details'); //Name Declaration For  CATEGORIES TABLES
	define('FREQUENT_TBL', 'frequent_tbl'); //Name Declaration For  CATEGORIES TABLES
	
/////////////////////////////////////////////////////////////////////////////////////////////////


?>